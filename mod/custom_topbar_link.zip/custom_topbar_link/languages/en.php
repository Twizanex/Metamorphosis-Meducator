<?php
	$english = array(
		'customtopbarlink:adminsettings' => "Enter the link text and URL for the custom topbar link.",
		'customtopbarlink:admintext' => "Link text:",
		'customtopbarlink:adminurl' => "Link URL:",
	);
	add_translation("en",$english);
?>